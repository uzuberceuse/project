package hotelReservation.dto.goods;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchResult {
	
	//private String tpicture;
	private String hid;
	private String hname;
	private int grade;
	private int tprice;
	
}
