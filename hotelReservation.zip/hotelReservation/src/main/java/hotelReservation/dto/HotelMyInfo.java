package hotelReservation.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HotelMyInfo {
	
	private String hid;
	private String hname;
	private String grade;
	private String location;
	private String hmail;
	private String hphone;

}