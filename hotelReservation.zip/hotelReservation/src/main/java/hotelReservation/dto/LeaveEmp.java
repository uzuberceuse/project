package hotelReservation.dto;

public class LeaveEmp {

}
