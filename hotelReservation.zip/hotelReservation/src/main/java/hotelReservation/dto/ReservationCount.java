package hotelReservation.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReservationCount {

	private String cid;
	private String cname;
	private String chargeCount;
	private String rname;
	private int cnt;
	
	
	
}
