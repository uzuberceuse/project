package hotelReservation.dto.reservation;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MyWishList {

	private String cid;
	private String hname;
	private String tcode;
	private String tname;
	private int tprice;
	private String img;
	
	
}
