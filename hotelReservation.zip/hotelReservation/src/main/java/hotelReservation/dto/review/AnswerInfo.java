package hotelReservation.dto.review;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnswerInfo {
	private String hname;
	private String answer;
	
	public AnswerInfo() {}
}
