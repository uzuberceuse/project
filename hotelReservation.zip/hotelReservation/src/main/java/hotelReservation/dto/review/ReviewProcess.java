package hotelReservation.dto.review;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewProcess {
	
	private String rid;
	private String cid;
	private String rcomment;
	private String display;

}
