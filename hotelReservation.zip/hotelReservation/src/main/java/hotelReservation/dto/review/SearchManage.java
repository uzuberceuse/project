package hotelReservation.dto.review;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchManage {
	
	private String type;
	private String id;
	private String rpno;
	private String answer;

}
