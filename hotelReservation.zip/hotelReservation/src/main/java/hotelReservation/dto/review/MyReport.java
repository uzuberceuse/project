package hotelReservation.dto.review;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MyReport {

	private String rpno;
	private String gname;
	private String rcomment;
	private String reason;
	private String status;
}
