package hotelReservation.dto.review;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchReview {
	private String hid;
	private String tcode;
	
	public SearchReview() {}
}
