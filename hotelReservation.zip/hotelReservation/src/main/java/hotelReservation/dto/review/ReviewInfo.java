package hotelReservation.dto.review;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewInfo {
	private String tcode;
	private String cid;
	private String tname;
	private String usedate;
	private String rid;
}
