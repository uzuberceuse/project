package hotelReservation.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerMyInfo {

	private String cid;
	private String cname;
	private String firstname;
	private String lastname;
	private String cmail;
	private String cphone;

}
